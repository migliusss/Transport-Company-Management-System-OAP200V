package com.oap200vGroupNumberFive.TransportCompanyManagementSystem.model;

public class Payments {

}
