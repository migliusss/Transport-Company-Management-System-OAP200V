package com.oap200vGroupNumberFive.TransportCompanyManagementSystem.view;

public class EmployeeInterface {
	
}
