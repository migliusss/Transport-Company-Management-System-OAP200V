package com.oap200vGroupNumberFive.TransportCompanyManagementSystem;

import com.oap200vGroupNumberFive.TransportCompanyManagementSystem.view.CustomerInterface;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args ) {
       new CustomerInterface();
    }
}
