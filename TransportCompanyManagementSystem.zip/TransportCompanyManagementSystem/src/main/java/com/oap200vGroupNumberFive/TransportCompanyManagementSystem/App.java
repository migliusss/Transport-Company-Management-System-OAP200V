package com.oap200vGroupNumberFive.TransportCompanyManagementSystem;

import com.oap200vGroupNumberFive.TransportCompanyManagementSystem.view.MainPage;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args ) {
       new MainPage();
    }
}
